var number_rows = 4;
var number_columns = 4;

var current_row = 0;
var current_column = 0;

var G_O = false;
var word;
var hint_given;
var dictionary;

window.onload = function(){
    init();
}

function init(){
var reset_button = document.getElementById("startover");
reset_button.disabled = true;
reset_button.innerText = "Loading..."
    const words = async() =>{
        const res = await fetch("https://api.masoudkf.com/v1/wordle", {
        headers: {
        "x-api-key": "sw0Tr2othT1AyTQtNDUE06LqMckbTiKWaVYhuirv",
    },});
    let Json = await res.json();
    return Json;
    }
    words().then(Json => {
        let dict= Json.dictionary;
        let random_num_gen = Number.parseInt(Math.random() * dict.length);
        word = dict[random_num_gen]["word"];
        hint_given = dict[random_num_gen]["hint"];
        word = word.toUpperCase();
        dictionary = dict;
        reset_button.disabled = false;
        reset_button.innerText = "Start over";


    });
    for(let rows=0;rows < number_rows;rows++){
        for(let columns = 0; columns < number_columns; columns++){
            let bo = document.createElement("span");
            bo.id = rows.toString()+"-"+columns.toString();
            bo.classList.add("box");
            bo.innerText = "";
            document.getElementById("game_board").appendChild(bo);


        }
    }
    document.addEventListener("keyup",(keyInput)=>{
        if(G_O){
            return;
        }

        if(keyInput.code>="KeyA"&&keyInput.code<="KeyZ"){
            if(current_column<number_columns){
                let current_box = document.getElementById(current_row.toString()+"-"+current_column.toString());
                if (current_box.innerText==""){
                    current_box.innerText = keyInput.code[3];
                    current_column++;
                }
            }
        }
        else if(keyInput.code == "Backspace"){
            if(current_column>0 && current_column<=number_columns){
                current_column--;
            }
            let current_box = document.getElementById(current_row.toString()+"-"+current_column.toString());
            current_box.innerText="";
        }
        else if(keyInput.code == "Enter"){
            if(current_column != 4){
                window.alert("You must complete the word first")
            }
            else{
                nextColumn();
                current_row+=1;
                current_column = 0;
            }

        }
        if(!G_O && current_row == number_rows){
            G_O = true;
            document.getElementById("answer").innerText = "You missed the word "+ word+" and lost!";
            
        
            
        }

    })
}

function nextColumn(){
    let right_counter = 0;
    let dict_count ={};
    for(let i = 0; i<word.length;i++){
        alph = word[i];
        if(dict_count[alph]){
            dict_count[alph]++;
        }
        else{
            dict_count[alph] = 1;
        }
    }
    for(let i = 0; i<word.length;i++){
        let current_box = document.getElementById(current_row.toString()+'-'+i.toString());
        let alph = current_box.innerText;
        if(word[i] == alph){
            current_box.classList.add("rightplace_color");
            right_counter++;
            dict_count[alph]-=1;
        }
        if(right_counter == number_rows){
            const img = document.getElementById("congrats")
            img.setAttribute('src', 'https://res.cloudinary.com/mkf/image/upload/v1675467141/ENSF-381/labs/congrats_fkscna.gif');
            document.getElementById('hint').innerText = "";
            document.getElementById('hint').innerText = "You got the word "+ word + " right";
            let board = document.getElementById('game_board');
            board.classList.toggle('hidden');
            G_O = true;
            
        }
    }


    for(let i = 0; i<word.length;i++){
        let current_box = document.getElementById(current_row.toString()+'-'+i.toString());
        let alph = current_box.innerText;
        if(!current_box.classList.contains("rightplace_color")){
            if(word.includes(alph)&&dict_count[alph]>0){
                current_box.classList.add("rightletter_color")
                dict_count[alph]-=1;
            }
            else{
                current_box.classList.add("wronglettercolor")
            
            }
        }

    }

}

const set_dark = ()=> {
    var display = document.body;
    display.classList.toggle("change_to_dark");

    const change_button = document.querySelectorAll('.button_style');
    change_button.forEach(i => i.classList.toggle('invert'));
    document.getElementById("darkness").blur();
}

const get_hint = () =>{
    document.getElementById("hint").innerText = hint_given;
    let hintmsg = document.getElementById("hint");
    hintmsg.classList.toggle("show");
    document.getElementById("hinted").blur();



}

const reset = () =>{
    G_O = false;
    current_column = 0;
    current_row = 0;
    document.getElementById('answer').innerText = "";
    document.getElementById('hint').innerText = "";
    let cong = document.getElementById('congrats');
    cong.removeAttribute('src');
    let board = document.getElementById('game_board');
    if(board.classList.contains('hidden')){
        board.classList.toggle('hidden');
    }
    
    for(i = 0; i < word.length; i++){
        for(j = 0;j<word.length; j++){
        let current_box = document.getElementById(i.toString()+'-'+j.toString());
        current_box.innerText = "";
        if(current_box.classList.contains('wronglettercolor')){
            current_box.classList.remove('wronglettercolor');
        }
        else if(current_box.classList.contains('rightletter_color')){
            current_box.classList.remove('rightletter_color');
        }
        else{
            current_box.classList.remove('rightplace_color');
        }
        document.getElementById("startover").blur();
    }
    }
    let random_num_gen = Number.parseInt(Math.random() * dictionary.length)
    word = dictionary[random_num_gen]["word"];
    word = word.toUpperCase();
    hint_given = dictionary[random_num_gen]["hint"];
    


}

const get_instruction = () =>{
    let rightside = document.getElementById("rightside");
    rightside.classList.toggle("show");
    document.getElementById("INST").blur();



}